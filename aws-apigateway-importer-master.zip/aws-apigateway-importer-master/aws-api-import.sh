#!/bin/bash

java -jar build/maven/aws-apigateway-swagger-importer-1.0.1-jar-with-dependencies.jar "$@"
